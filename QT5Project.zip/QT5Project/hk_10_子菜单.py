import sys
from PyQt5.QtWidgets import QMainWindow, QAction, QMenu, QApplication

# 这个例子里，有两个子菜单，一个在file菜单下面，一个在file的import下面。


class Example(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        menubar = self.menuBar()
        fileMenu = menubar.addMenu('File')
        # 使用QMenu创建一个新菜单。
        impMenu = QMenu('Import', self)
        impAct = QAction('Import mail', self)
        # 使用addAction添加一个动作。
        impMenu.addAction(impAct)
        newAct = QAction('New', self)
        fileMenu.addAction(newAct)
        fileMenu.addMenu(impMenu)
        self.setGeometry(300, 300, 300, 200)
        self.setWindowTitle('Submenu')
        self.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())
