import sys
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QWidget, QLCDNumber, QSlider,
    QVBoxLayout, QApplication)
# 显示了QtGui.QLCDNumber和QtGui.QSlider模块，我们能拖动滑块让数字跟着发生改变。


class Example(QWidget):

    def __init__(self):
        super().__init__()

        self.init_ui()


    def init_ui(self):
        # 显示一个带有类似液晶显示屏效果的数字。
        lcd = QLCDNumber(self)
        # 提供了一个垂直或水平滑动条
        sld = QSlider(Qt.Horizontal, self)

        vbox = QVBoxLayout()
        vbox.addWidget(lcd)
        vbox.addWidget(sld)

        self.setLayout(vbox)
        # 这里是把滑块的变化和数字的变化绑定在一起。
        sld.valueChanged.connect(lcd.display)
        # sender是信号的发送者，receiver是信号的接收者，slot是对这个信号应该做出的反应。
        self.setGeometry(300, 300, 250, 150)
        self.setWindowTitle('Signal and slot')
        self.show()


if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())