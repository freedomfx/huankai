import sys
from PyQt5.QtWidgets import QMainWindow, QAction, QApplication

# 本例创建了一个行为菜单。这个行为／动作能切换状态栏显示或者隐藏。


class Example(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.statusbar = self.statusBar()
        self.statusbar.showMessage('Ready')
        menubar = self.menuBar()
        # 用checkable选项创建一个能选中的菜单。
        viewMenu = menubar.addMenu('View')
        # viewMenu2 = menubar.addMenu('View2') 可以参加第二个菜单
        viewStatAct = QAction('View statusbar', self, checkable=True)
        viewStatAct.setStatusTip('View statusbar')
        # 默认设置为选中状态。
        viewStatAct.setChecked(True)
        viewStatAct.triggered.connect(self.toggleMenu)
        viewMenu.addAction(viewStatAct)
        self.setGeometry(300, 300, 300, 200)
        self.setWindowTitle('Check menu')
        self.show()

    def toggleMenu(self, state):
        # 依据选中状态切换状态栏的显示与否。
        if state:
            self.statusbar.show()
        else:
            self.statusbar.hide()


if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())