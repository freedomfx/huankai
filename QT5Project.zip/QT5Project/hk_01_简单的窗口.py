import sys
from PyQt5.QtWidgets import QApplication, QWidget

# 这句代码的作用是判断当前文件是否为主文件
# 如果不是主文件，则其下面的内容不被执行
if __name__ == '__main__':
    #创建应用对象
    app = QApplication(sys.argv)
    # QWidge控件是一个用户界面的基本控件，它提供了基本的应用构造器。
    # 默认情况下，构造器是没有父级的，没有父级的构造器被称为窗口（window）。
    w = QWidget()
    # resize()方法改变窗口大小，宽度500，高度300
    w.resize(250, 150)
    # 设置窗口位置(针对屏幕左上角)
    w.move(300, 300)
    # 给窗口添加标题
    w.setWindowTitle('simple')
    # 显示
    w.show()
    # sys.exit()方法能确保主循环安全退出。外部环境能通知主控件怎么结束。
    sys.exit(app.exec_())
