import sys
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5.QtGui import QIcon

# 面向对象编程最重要的三个部分是类(class)、数据和方法。
# 我们创建了一个类的调用，这个类继承自QWidget。
# 这就意味着，我们调用了两个构造器，一个是这个类本身的，一个是这个类继承的。
# super()构造器方法返回父级的对象。__init__()方法是构造器的一个方法。
# 构造器作为一种方法，负责类中成员变量（域）的初始化


class Example(QWidget):
    def __init__(self):
        super().__init__()

        # 使用init_ui()方法创建一个GUI
        self.init_ui()

    def init_ui(self):
        """
        setGeometry()
        把窗口放到屏幕上并且设置窗口大小。
        参数分别代表屏幕坐标的x、y和窗口大小的宽、高。
        也就是说这个方法是resize()和move()的合体。
        """
        self.setGeometry(300, 300, 300, 220)
        self.setWindowTitle('Icon')
        # 添加图标
        # 先创建一个QIcon对象，接收一个路径作为参数显示图标
        self.setWindowIcon(QIcon('web.png'))
        self.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())