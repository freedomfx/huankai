import sys
from PyQt5.QtWidgets import QWidget, QToolTip, QPushButton, QApplication
from PyQt5.QtGui import QFont


class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        # 为应用创建一个提示框
        # 设置提示框的字体，使用10px的SansSerif字体
        QToolTip.setFont(QFont('SansSerif', 10))
        # 调用setToolTip()创建提示框可以使用富文本格式的内容
        self.setToolTip('This is a <b>QWidget</b> widget')
        # 创建一个按钮，并且为按钮添加了一个提示框
        btn = QPushButton('Button',self)
        btn.setToolTip('This is a <b>QPushButton</b> widget')
        # 调整按钮的宽度，并让按钮再屏幕上显示出来
        # sizeHint()方法提供了一个默认的按钮大小。
        btn.resize(btn.sizeHint())
        btn.move(50, 50)
        self.setGeometry(300, 300, 300, 300)
        self.setWindowTitle('Tooltips')
        self.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())
