import math


def show_wel(version):
    """
    显示计算器首界面
    :param version: 版本号
    :return: 返回选择的不同操作
    """
    print("*" * 50)
    print("欢迎使用简易计算器 %s " % version, end="\n\n")
    print("请选择您要实现的功能：")
    print("1.标准")
    print("2.科学")
    print("3.程序员")
    print("4.退出系统")
    print("*" * 50)
    ope = input("请输入您想进行的操作：")
    print("您选择的操作是：%d" % int(ope))
    return ope


def sci_cal_wel():
    """
    显示科学计算器首界面
    :return:
    """
    print("*" * 50)
    print("选择要进行的操作：")
    print("1.X²")
    print("2.√x")
    sci_ope = input("请输入选择的操作:")
    while sci_ope not in ["1", "2"]:
        sci_ope = input("您的输入有误,请重新输入:")
    return sci_ope
# 标准计算器操作
# eval() 函数用来执行一个字符串表达式，并返回表达式的值


def stan_cal():
    """
    该函数实现标准计算器操作，包括加减乘除以及取余运算
    """
    num_a, ope, num_b = input("请输入操作")
    if ope == "+":
        print("%d + %d = %d" % (int(num_a), int(num_b), int(num_a) + int(num_b)))
    elif ope == "-":
        print("%d - %d = %d" % (int(num_a), int(num_b), int(num_a) - int(num_b)))
    elif ope == "*":
        print("%d * %d = %d" % (int(num_a), int(num_b), int(num_a) * int(num_b)))
    elif ope == "/":
        print("%d / %d = %.20f" % (int(num_a), int(num_b), int(num_a) / int(num_b)))
    elif ope == "%":
        print("%d %% %d = %d" % (int(num_a), int(num_b), int(num_a) % int(num_b)))


def sci_cal(sci_ope):
    """
    实现简单科学计算器，仅包括平方操作和开根操作
    :param sci_ope: 传递过来要进行的操作
    """
    if sci_ope == "1":
        ope = int(input("请输入操作数："))
        print("%d² = %d" % (ope, math.pow(ope, 2)))
    elif sci_ope == "2":
        ope = int(input("请输入操作数："))
        print("√%d = %.20f" % (ope, math.sqrt(ope)))


def pro_cal():
    """
    实现简单程序员计算器，实现十进制转换为二进制、八进制、十六进制
    """
    dec = int(input("请输入十进制数字："))
    print("转换为二进制为：", bin(dec))
    print("转换为八进制为：", oct(dec))
    print("转换为十六进制为：", hex(dec))

