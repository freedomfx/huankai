# 编写完整的二元计算器的程序
# 举例说明如何进行复用和扩展

import tools


version = "V 1.0"

while True:
    operate_str = tools.show_wel(version)
    if operate_str in ["1", "2", "3", "4"]:
        # 标准计算器（+ - * /）
        if operate_str == "1":
            tools.stan_cal()
        # 科学计算器（平方 三角运算等）
        elif operate_str == "2":
            sci_ope = tools.sci_cal_wel()
            tools.sci_cal(sci_ope)
        # 程序员计算器（进制转换）
        elif operate_str == "3":
            tools.pro_cal()
    # 退出系统
    elif operate_str == "4":
        print("欢迎再次使用计算器！")
        break
    else:
        print("您的输入错误，请重新输入!")
