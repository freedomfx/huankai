# 作者：KaiSarH
# 日期：2019/11/4
from luckinmain import *
from normal import *
from setmeal import *
from activity import *
import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap

class Luckin_Main(QMainWindow):
    def __init__(self):
        # 界面初始化
        QMainWindow.__init__(self)
        self.main_ui = Ui_MainWindow()
        self.main_ui.setupUi(self)
        # 给按钮绑定方法
        btn_del = self.main_ui.pushButton_5
        btn_del.clicked.connect(self.order_del)
        btn_delone = self.main_ui.pushButton_8
        btn_delone.clicked.connect(self.order_decline)
        btn_num = self.main_ui.pushButton_6
        btn_num.clicked.connect(self.order_num)
        self.btn_tip = self.main_ui.pushButton_7
        self.btn_tip.clicked.connect(self.order_tip)
        # 设置按钮为当前不可用
        self.btn_tip.setEnabled(False)
        # 定义列表
        self.num = []
        self.new_num = []

    # 主界面显示
    def person(self):
        # 主界面贴图
        self.main_ui.label_8.setPixmap(QPixmap('./Picture/主界面.png'))
        # 将图片完全填充
        self.main_ui.label_8.setScaledContents(True)
        # 初始化储值卡余额
        self.balance = 500
        # 初始化优惠券数量
        self.coupons = 1
        # 显示余额和券数量
        self.main_ui.label_2.setText(str(self.balance))
        self.main_ui.label_5.setText(str(self.coupons))
        # 显示主界面
        luckinmain.show()

    # 删除操作——直接删除一行
    def order_del(self):
        # 获取所选行索引
        row_index = luckinmain.main_ui.tableWidget.currentRow()
        if row_index != -1:
            # 删除
            luckinmain.main_ui.tableWidget.removeRow(row_index)

    # 删除操作——删除某一种商品一份
    def order_decline(self):
        self.price_Cappuccino = 18.5
        self.price_Latte = 11.0
        self.price_Mocha = 13.0
        self.price_Americano = 13.5
        self.price_Macchiato = 10.0
        # 获取当前所选的行
        current_row = luckinmain.main_ui.tableWidget.currentRow()
        # 将字符串转换为整型
        num = luckinmain.main_ui.tableWidget.item(current_row, 1).text()
        num = eval(num.replace(num[0], ''))
        # 判断是否大于1
        if num == 1:
            # 等于1的话直接删除
            luckinmain.main_ui.tableWidget.removeRow(current_row)
        else:
            # 大于1则进行判断 修改数量和价格
            num -= 1
            kind = luckinmain.main_ui.tableWidget.item(current_row, 0).text()
            luckinmain.main_ui.tableWidget.setItem(current_row, 1, QTableWidgetItem("×" + str(num)))
            if kind == '卡布奇诺':
                luckinmain.main_ui.tableWidget.setItem(current_row, 2,
                                                       QTableWidgetItem(str(self.price_Cappuccino * num)))
            elif kind == '拿铁':
                luckinmain.main_ui.tableWidget.setItem(current_row, 2,
                                                       QTableWidgetItem(str(self.price_Latte * num)))
            elif kind == '摩卡':
                luckinmain.main_ui.tableWidget.setItem(current_row, 2,
                                                       QTableWidgetItem(str(self.price_Mocha * num)))
            elif kind == '标准美式':
                luckinmain.main_ui.tableWidget.setItem(current_row, 2,
                                                       QTableWidgetItem(str(self.price_Americano * num)))
            elif kind == '焦糖玛奇朵':
                luckinmain.main_ui.tableWidget.setItem(current_row, 2,
                                                       QTableWidgetItem(str(self.price_Macchiato * num)))

    # 结算
    def order_num(self):
        # 设置打印小票按钮为可用
        self.btn_tip.setEnabled(True)
        # 遍历所有行
        for row_index in range(luckinmain.main_ui.tableWidget.rowCount()):
            # 将每一行的第三项值(数量)添加到num列表里
            self.num.append(luckinmain.main_ui.tableWidget.item(row_index, 2).text())

        # 将num中的字符转换成int型
        self.new_num = eval('[' + (','.join(self.num)) + ']')
        # 将new_num列表值求和为需要支付的所有钱数
        self.money = sum(self.new_num)

        # 有优惠券时
        if self.coupons >= 1:
            # 消息提示框
            button = QMessageBox.information(self, "温馨提示", "是否使用优惠券", QMessageBox.Yes | QMessageBox.No)
            # 使用优惠券
            if button == QMessageBox.Yes:
                # 当前优惠券数量减一
                self.coupons = self.coupons -1
                self.main_ui.label_5.setText(str(self.coupons))

                # 余额足够 一张优惠卷为20元
                if self.balance >= (self.money - self.coupons * 20):
                    QMessageBox.information(self, "恭喜您", "付款成功！", QMessageBox.Yes)
                    self.balance = self.balance - self.money + self.coupons * 20
                    self.main_ui.label_2.setText(str(self.balance))
                else:
                    QMessageBox.information(self, "对不起", "您的储值卡余额不足！", QMessageBox.Yes)
            # 不使用优惠券
            else:
                if self.balance >= self.money:
                    QMessageBox.information(self, "恭喜您", "付款成功！", QMessageBox.Yes)
                    self.balance = self.balance - self.money
                    self.main_ui.label_2.setText(str(self.balance))
                else:
                    QMessageBox.information(self, "对不起", "您的储值卡余额不足！", QMessageBox.Yes)
        # 没有优惠券时
        else:
            if self.balance >= self.money:
                QMessageBox.information(self, "恭喜您", "付款成功！", QMessageBox.Yes)
                self.balance = self.balance - self.money
                self.main_ui.label_2.setText(str(self.balance))
            else:
                QMessageBox.information(self, "对不起", "您的储值卡余额不足！", QMessageBox.Yes)

    # 打印小票
    def order_tip(self):
        # 打开本地txt文件
        with open("luckinbill.txt", "w") as f:
            # 遍历行
            for row_index in range(luckinmain.main_ui.tableWidget.rowCount()):
                # 遍历列
                for column_index in range(luckinmain.main_ui.tableWidget.columnCount()):
                    # 将tableWidget数据写入文件
                    f.write(luckinmain.main_ui.tableWidget.item(row_index, column_index).text() + "\n")
            f.write("合计：" + str(self.money) + "元")
        f.close()

class Normal(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.normal_ui = Ui_Normal()
        self.normal_ui.setupUi(self)

        # 初始化各基本餐加入订单按钮点击次数
        self.bt1 = 0
        self.bt2 = 0
        self.bt3 = 0
        self.bt4 = 0
        self.bt6 = 0
        # 初始化返回按钮点击次数
        self.bt5 = 0
        # 按钮绑定方法
        btn_Cappuccino = self.normal_ui.pushButton
        btn_Cappuccino.clicked.connect(self.order_Cappuccino)
        btn_Latte = self.normal_ui.pushButton_2
        btn_Latte.clicked.connect(self.order_Latte)
        btn_Mocha = self.normal_ui.pushButton_3
        btn_Mocha.clicked.connect(self.order_Mocha)
        btn_Americano = self.normal_ui.pushButton_4
        btn_Americano.clicked.connect(self.order_Americano)
        btn_ice = self.normal_ui.pushButton_5
        btn_ice.clicked.connect(self.order_ice)
        btn_return = self.normal_ui.pushButton_6
        btn_return.clicked.connect(self.nor_show)
    # 显示基本餐界面
    def nor_order(self):
        # 绘图,设置背景,并把图片铺满容器
        self.normal_ui.label_3.setPixmap(QPixmap('./picture/卡布奇诺.png'))
        self.normal_ui.label_3.setScaledContents(True)
        self.normal_ui.label_6.setPixmap(QPixmap('./picture/拿铁.png'))
        self.normal_ui.label_6.setScaledContents(True)
        self.normal_ui.label_9.setPixmap(QPixmap('./picture/摩卡.png'))
        self.normal_ui.label_9.setScaledContents(True)
        self.normal_ui.label_12.setPixmap(QPixmap('./picture/标准美式.png'))
        self.normal_ui.label_12.setScaledContents(True)
        self.normal_ui.label_15.setPixmap(QPixmap('./picture/焦糖玛奇朵.png'))
        self.normal_ui.label_15.setScaledContents(True)
        # 基本餐价格
        self.price_Cappuccino = 18.5
        self.price_Latte = 11.0
        self.price_Mocha = 13.0
        self.price_Americano = 13.5
        self.price_Macchiato = 10.0
        # 显示价格
        self.normal_ui.label.setText(str(self.price_Cappuccino)+"元/份")
        self.normal_ui.label_4.setText(str(self.price_Latte)+"元/份")
        self.normal_ui.label_7.setText(str(self.price_Mocha)+"元/份")
        self.normal_ui.label_10.setText(str(self.price_Americano)+"元/份")
        self.normal_ui.label_13.setText(str(self.price_Macchiato)+"元/份")
        # 显示界面
        normal.show()

    # 计算不同餐品点击次数
    def order_Cappuccino(self):
        self.bt1 += 1

    def order_Latte(self):
        self.bt2 += 1

    def order_Mocha(self):
        self.bt3 += 1

    def order_Americano(self):
        self.bt4 += 1


    def order_ice(self):
        self.bt5 += 1

    def nor_show(self):
        self.bt6 += 1

        # 隐藏界面
        normal.hide()

        # 获取所选各基本餐的数量对应的价格
        self.num_Cappuccino = self.price_Cappuccino * self.bt1
        self.num_Latte = self.price_Latte * self.bt2
        self.num_Mocha = self.price_Mocha * self.bt3
        self.num_Americano = self.price_Americano * self.bt4
        self.num_Macchiato = self.price_Macchiato * self.bt6

        # 不是第一次进入该界面
        if self.bt6 > 1:
            for row_index in range(luckinmain.main_ui.tableWidget.rowCount()):
                # 获取tableWidget的所有名称，并放入name列表
                name.append(luckinmain.main_ui.tableWidget.item(row_index, 0).text())
            if '卡布奇诺' in name:
                # 重新设置该行的数量和价格
                luckinmain.main_ui.tableWidget.setItem(name.index('卡布奇诺'), 1, QTableWidgetItem("×" + str(self.bt1)))
                luckinmain.main_ui.tableWidget.setItem(name.index('卡布奇诺'), 2, QTableWidgetItem(str(self.num_Cappuccino)))
            if '卡布奇诺' not in name:
                # 已选择
                if self.bt1 != 0:
                    # 添加一行数据
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_2.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt1)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Cappuccino)))
            if '拿铁' in name:
                luckinmain.main_ui.tableWidget.setItem(name.index('拿铁'), 1, QTableWidgetItem("×" + str(self.bt2)))
                luckinmain.main_ui.tableWidget.setItem(name.index('拿铁'), 2, QTableWidgetItem(str(self.num_Latte)))
            if '拿铁' not in name:
                if self.bt2 != 0:
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_5.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt2)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Latte)))
            if '摩卡' in name:
                luckinmain.main_ui.tableWidget.setItem(name.index('摩卡'), 1, QTableWidgetItem("×" + str(self.bt3)))
                luckinmain.main_ui.tableWidget.setItem(name.index('摩卡'), 2, QTableWidgetItem(str(self.num_Mocha)))
            if '摩卡' not in name:
                if self.bt3 != 0:
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_8.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt3)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Mocha)))
            if '标准美式'in name:
                luckinmain.main_ui.tableWidget.setItem(name.index('标准美式'), 1, QTableWidgetItem("×" + str(self.bt4)))
                luckinmain.main_ui.tableWidget.setItem(name.index('标准美式'), 2, QTableWidgetItem(str(self.num_Americano)))
            if '标准美式' not in name:
                if self.bt4 != 0:
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_11.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt4)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Americano)))
            if '焦糖玛奇朵' in name:
                luckinmain.main_ui.tableWidget.setItem(name.index('焦糖玛奇朵'), 1, QTableWidgetItem("×" + str(self.bt6)))
                luckinmain.main_ui.tableWidget.setItem(name.index('焦糖玛奇朵'), 2, QTableWidgetItem(str(self.num_Macchiato)))
            if '焦糖玛奇朵' not in name:
                if self.bt5 != 0:
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_14.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt6)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Macchiato)))
        # 第一次进入该界面
        else:
            if self.bt1 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_2.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt1)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Cappuccino)))
            if self.bt2 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_5.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt2)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Latte)))
            if self.bt3 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_8.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt3)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Mocha)))
            if self.bt4 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_11.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt4)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Americano)))
            if self.bt5 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(normal.normal_ui.label_14.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt6)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_Macchiato)))

class Package(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.package_ui = Ui_Setmeal()
        self.package_ui.setupUi(self)

        # 初始化各套餐加入订单按钮点击次数
        self.bt1 = 0
        self.bt2 = 0
        # 初始化返回按钮点击次数
        self.bt3 = 0
        # 按钮绑定方法
        btn_pack1 = self.package_ui.pushButton
        btn_pack1.clicked.connect(self.order_pack1)
        btn_pack2 = self.package_ui.pushButton_2
        btn_pack2.clicked.connect(self.order_pack2)
        btn_return = self.package_ui.pushButton_3
        btn_return.clicked.connect(self.pac_show)

    # 显示套餐界面
    def pac_order(self):
        self.package_ui.label_5.setPixmap(QPixmap('./picture/套餐2.png'))
        self.package_ui.label_5.setScaledContents(True)
        self.package_ui.label_6.setPixmap(QPixmap('./picture/套餐1.png'))
        self.package_ui.label_6.setScaledContents(True)
        # 套餐价格
        self.price_pack1 = 89.0
        self.price_pack2 = 67.0
        self.package_ui.label.setText(str(self.price_pack1)+"元/份")
        self.package_ui.label_2.setText(str(self.price_pack2)+"元/份")
        package.show()

    def order_pack1(self):
        self.bt1 += 1

    def order_pack2(self):
        self.bt2 += 1

    def pac_show(self):
        self.bt3 += 1

        package.hide()

        self.num_pack1 = self.price_pack1 * self.bt1
        self.num_pack2 = self.price_pack2 * self.bt2

        if self.bt3 > 1:
            for row_index in range(luckinmain.main_ui.tableWidget.rowCount()):
                name.append(luckinmain.main_ui.tableWidget.item(row_index, 0).text())
            if '咖啡香茶外送套餐' in name:
                luckinmain.main_ui.tableWidget.setItem(name.index('咖啡香茶外送套餐'), 1, QTableWidgetItem("×" + str(self.bt1)))
                luckinmain.main_ui.tableWidget.setItem(name.index('咖啡香茶外送套餐'), 2, QTableWidgetItem(str(self.num_pack1)))
            if '咖啡香茶外送套餐' not in name:
                if self.bt1 != 0:
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(package.package_ui.label_3.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt1)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_pack1)))
            if '咖啡冰淇淋套餐' in name:
                luckinmain.main_ui.tableWidget.setItem(name.index('咖啡冰淇淋套餐'), 1, QTableWidgetItem("×" + str(self.bt2)))
                luckinmain.main_ui.tableWidget.setItem(name.index('咖啡冰淇淋套餐'), 2, QTableWidgetItem(str(self.num_pack2)))
            if '咖啡冰淇淋套餐' not in name:
                if self.bt2 != 0:
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(package.package_ui.label_4.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt2)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_pack2)))
        else:
            if self.bt1 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(package.package_ui.label_3.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt1)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_pack1)))
            if self.bt2 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(package.package_ui.label_4.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt2)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_pack2)))

class Activity(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.activity_ui = Ui_Activity()
        self.activity_ui.setupUi(self)

        # 初始化各活动加入订单按钮点击次数
        self.bt1 = 0
        # 初始化返回按钮点击次数
        self.bt3 = 0
        # 绑定方法
        btn_act1 = self.activity_ui.pushButton
        btn_act1.clicked.connect(self.order_act1)
        btn_act2 = self.activity_ui.pushButton_2
        btn_act2.clicked.connect(self.order_act2)
        btn_return = self.activity_ui.pushButton_3
        btn_return.clicked.connect(self.act_show)

    def act_order(self):
        self.activity_ui.label_4.setPixmap(QPixmap('./picture/活动1.png'))
        self.activity_ui.label_4.setScaledContents(True)
        self.activity_ui.label_8.setPixmap(QPixmap('./picture/活动2.png'))
        self.activity_ui.label_8.setScaledContents(True)
        # 活动价格
        self.price_act1 = 29.0
        self.price_act2 = 69.0
        self.activity_ui.label.setText(str(self.price_act1) + "元/份  原价:"+str(self.price_act1 + 7) + "元/份")
        self.activity_ui.label_5.setText(str(self.price_act2) + "元/份  原价:"+str(self.price_act2 + 10) + "元/份")
        activity.show()

    def order_act1(self):
        self.bt1 += 1

    def order_act2(self):
        QMessageBox.information(self, "对不起", "活动还没有开始，敬请期待！", QMessageBox.Yes)

    def act_show(self):
        self.bt3 += 1

        activity.hide()

        self.num_act1 = self.price_act1 * self.bt1

        if self.bt3 > 1:
            for row_index in range(luckinmain.main_ui.tableWidget.rowCount()):
                name.append(luckinmain.main_ui.tableWidget.item(row_index, 0).text())
            if '草莓芝士茶' in name:
                luckinmain.main_ui.tableWidget.setItem(name.index('草莓芝士茶'), 1, QTableWidgetItem("×" + str(self.bt1)))
                luckinmain.main_ui.tableWidget.setItem(name.index('草莓芝士茶'), 2, QTableWidgetItem(str(self.num_act1)))
            if '草莓芝士茶' not in name:
                if self.bt1 != 0:
                    row_count = luckinmain.main_ui.tableWidget.rowCount()
                    luckinmain.main_ui.tableWidget.insertRow(row_count)
                    luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(activity.activity_ui.label_3.text()))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt1)))
                    luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_act1)))
        else:
            if self.bt1 != 0:
                row_count = luckinmain.main_ui.tableWidget.rowCount()
                luckinmain.main_ui.tableWidget.insertRow(row_count)
                luckinmain.main_ui.tableWidget.setItem(row_count, 0, QTableWidgetItem(activity.activity_ui.label_3.text()))
                luckinmain.main_ui.tableWidget.setItem(row_count, 1, QTableWidgetItem("×" + str(self.bt1)))
                luckinmain.main_ui.tableWidget.setItem(row_count, 2, QTableWidgetItem(str(self.num_act1)))

if __name__=="__main__":
    app = QApplication(sys.argv)

    luckinmain = Luckin_Main()
    normal = Normal()
    package = Package()
    activity = Activity()
    # 显示主界面
    luckinmain.person()
    # 绑定按钮
    btn_normal = luckinmain.main_ui.pushButton_2
    btn_normal.clicked.connect(normal.nor_order)
    btn_package = luckinmain.main_ui.pushButton_3
    btn_package.clicked.connect(package.pac_order)
    btn_activity = luckinmain.main_ui.pushButton_4
    btn_activity.clicked.connect(activity.act_order)
    # 初始化name列表
    name = []

    sys.exit(app.exec_())
