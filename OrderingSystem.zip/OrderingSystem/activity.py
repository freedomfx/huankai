from PyQt5 import QtCore, QtWidgets
from PyQt5.QtGui import QIcon


class Ui_Activity(object):
    def setupUi(self, Form):
        # 设置活动页面ID
        Form.setObjectName("Form")
        # 设置活动页面大小
        Form.resize(639, 335)
        # 添加"加入订单"按钮
        self.pushButton = QtWidgets.QPushButton(Form)
        self.pushButton.setGeometry(QtCore.QRect(50, 240, 93, 31))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Form)
        self.pushButton_2.setGeometry(QtCore.QRect(300, 240, 93, 31))
        self.pushButton_2.setObjectName("pushButton_2")

        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(11, 220, 201, 20))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(20, 200, 161, 16))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Form)
        self.label_3.setGeometry(QtCore.QRect(50, 180, 91, 16))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Form)
        self.label_4.setGeometry(QtCore.QRect(30, 30, 141, 141))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(Form)
        self.label_5.setGeometry(QtCore.QRect(261, 220, 201, 20))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Form)
        self.label_6.setGeometry(QtCore.QRect(270, 200, 161, 16))
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(Form)
        self.label_7.setGeometry(QtCore.QRect(310, 180, 61, 16))
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(Form)
        self.label_8.setGeometry(QtCore.QRect(280, 30, 151, 141))
        self.label_8.setObjectName("label_8")
        # 设置返回按钮
        self.pushButton_3 = QtWidgets.QPushButton(Form)
        self.pushButton_3.setGeometry(QtCore.QRect(490, 250, 101, 31))
        self.pushButton_3.setObjectName("pushButton_3")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        # 设置活动页面标题
        Form.setWindowTitle(_translate("Form", "热销活动"))
        # 设置活动页面窗口图标
        Form.setWindowIcon(QIcon('./picture/activity.png'))
        # 设置加入"加入订单"按钮内容
        self.pushButton.setText(_translate("Form", "加入订单"))
        self.pushButton_2.setText(_translate("Form", "加入订单"))
        # 设置标签内容
        self.label.setText(_translate("Form", "钱1"))
        self.label_2.setText(_translate("Form", "2018.10.1-2018.10.31"))
        self.label_3.setText(_translate("Form", "草莓芝士茶"))
        self.label_4.setText(_translate("Form", "TextLabel"))
        self.label_5.setText(_translate("Form", "钱2"))
        self.label_6.setText(_translate("Form", "2018.11.1-2018.11.11"))
        self.label_7.setText(_translate("Form", "小雪荔枝冰"))
        self.label_8.setText(_translate("Form", "TextLabel"))
        self.pushButton_3.setText(_translate("Form", "返回"))
