import sys
import requests
import json

from PyQt5.QtWidgets import QApplication, QWidget, QMessageBox, QPushButton, QLineEdit, QLabel
from PyQt5.QtGui import QIcon

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.70 Safari/537.36'
}


def reform_fl(str_fl):
    """
    将风力转换为正常输出
    :param str_fl: 不正常输入
    :return: 正常输出
    """
    new_str = str_fl.split("[")[2].split("]")[0]
    if new_str.startswith("<"):
        result = new_str.split("<")[1]
    else:
        result = new_str
    return result


# setGeometry(X,Y,宽,高)
class FindWeather(QWidget):
    def __init__(self):
        super().__init__()
        self.lb = QLabel(self)
        self.lb.setGeometry(70, 25, 80, 40)
        self.lb.setText('请输入城市：')
        self.textbox = QLineEdit(self)
        self.textbox.setGeometry(150, 30, 130, 30)
        self.findButton = QPushButton('查询', self)
        self.findButton.setGeometry(60, 85, 100, 40)
        self.quitButton = QPushButton('退出', self)
        self.quitButton.clicked.connect(self.close)
        self.findButton.clicked.connect(self.find_weather)
        self.quitButton.setGeometry(190, 85, 100, 40)
        self.setGeometry(500, 500, 350, 150)
        self.setWindowTitle('Icon')
        self.setWindowTitle('天气查询,目前仅支持单次查询')
        self.setWindowIcon(QIcon('weather.png'))
        self.show()

    def find_weather(self):
        city_name = self.textbox.text()
        weather_url = 'http://wthrcdn.etouch.cn/weather_mini?city={}'.format(city_name)
        city_response = requests.get(weather_url, headers=headers)
        weather_dict = json.loads(city_response.text)
        if weather_dict.get('desc') == 'invilad-citykey':
            self.wrong_city()
        elif weather_dict.get('desc') == 'OK':
            forecast_weather = weather_dict.get('data').get('forecast')
            ganmao = weather_dict.get('data').get('ganmao')
            today = '日期:' + forecast_weather[0].get('date') + '\n' \
                    + '最高温度:' + forecast_weather[0].get('high') + '\n' \
                    + '最低温度:' + forecast_weather[0].get('low') + '\n' \
                    + '风向:' + forecast_weather[0].get('fengxiang') + '\n' \
                    + '风力:' + reform_fl(forecast_weather[0].get('fengli')) + '\n' \
                    + '天气状况:' + forecast_weather[0].get('type') + '\n'
            today_add1 = '日期:' + forecast_weather[1].get('date') + '\n' \
                         + '最高温度:' + forecast_weather[1].get('high') + '\n' \
                         + '最低温度:' + forecast_weather[1].get('low') + '\n' \
                         + '风向:' + forecast_weather[1].get('fengxiang') + '\n' \
                         + '风力:' + reform_fl(forecast_weather[1].get('fengli')) + '\n' \
                         + '天气状况:' + forecast_weather[1].get('type') + '\n'
            today_add2 = '日期:' + forecast_weather[2].get('date') + '\n' \
                         + '最高温度:' + forecast_weather[2].get('high') + '\n' \
                         + '最低温度:' + forecast_weather[2].get('low') + '\n' \
                         + '风向:' + forecast_weather[2].get('fengxiang') + '\n' \
                         + '风力:' + reform_fl(forecast_weather[2].get('fengli')) + '\n' \
                         + '天气状况:' + forecast_weather[2].get('type') + '\n'
            today_add3 = '日期:' + forecast_weather[3].get('date') + '\n' \
                         + '最高温度:' + forecast_weather[3].get('high') + '\n' \
                         + '最低温度:' + forecast_weather[3].get('low') + '\n' \
                         + '风向:' + forecast_weather[3].get('fengxiang') + '\n' \
                         + '风力:' + reform_fl(forecast_weather[3].get('fengli')) + '\n' \
                         + '天气状况:' + forecast_weather[3].get('type') + '\n'
            today_add4 = '日期:' + forecast_weather[4].get('date') + '\n' \
                         + '最高温度:' + forecast_weather[4].get('high') + '\n' \
                         + '最低温度:' + forecast_weather[4].get('low') + '\n' \
                         + '风向:' + forecast_weather[4].get('fengxiang') + '\n' \
                         + '风力:' + reform_fl(forecast_weather[4].get('fengli')) + '\n' \
                         + '天气状况:' + forecast_weather[4].get('type') + '\n'
            day = [today, today_add1, today_add2, today_add3, today_add4]
            show_weather.show_ui(city=city_name, info=ganmao, day=day)

    def closeEvent(self, event):
        reply = QMessageBox.question(self, '退出',
                                     "确定退出?", QMessageBox.Yes |
                                     QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()

    def wrong_city(self):
        QMessageBox.information(self, '选择错误',
                                '输入城市无查询结果，请重新输入', QMessageBox.Yes |
                                QMessageBox.Yes)


class ShowWeather(QWidget):
    def show_ui(self, city, info, day):
        self.setGeometry(500, 500, 720, 300)
        title = city + "近五天天气状况"
        self.setWindowTitle(title)
        self.setWindowIcon(QIcon('weather_info.png'))
        lb = QLabel(self)
        lb.setGeometry(70, 25, 720, 50)
        lb.setText(info)
        lb.setStyleSheet("color:red;")
        for i in range(1, 6):
            self.add_one_label(i, day[i - 1])
        self.show()

    def add_one_label(self, num, day):
        x = 20 * num + 120 * (num - 1)
        info = day.split('\n')
        lb_day1 = QLabel(self)
        lb_day1.setGeometry(x, 100, 120, 20)
        lb_day1.setText(info[0])
        lb_day2 = QLabel(self)
        lb_day2.setGeometry(x, 120, 120, 20)
        lb_day2.setText(info[1])
        lb_day3 = QLabel(self)
        lb_day3.setGeometry(x, 140, 120, 20)
        lb_day3.setText(info[2])
        lb_day4 = QLabel(self)
        lb_day4.setGeometry(x, 160, 120, 20)
        lb_day4.setText(info[3])
        lb_day5 = QLabel(self)
        lb_day5.setGeometry(x, 180, 120, 20)
        lb_day5.setText(info[4])
        lb_day6 = QLabel(self)
        lb_day6.setGeometry(x, 200, 120, 20)
        lb_day6.setText(info[5])


if __name__ == '__main__':
    app = QApplication(sys.argv)
    find_weather = FindWeather()
    show_weather = ShowWeather()
    sys.exit(app.exec())
